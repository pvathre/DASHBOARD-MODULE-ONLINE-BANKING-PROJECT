package dao;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entity.Address;

public class AddressDAOImpl implements AddressDAO {

	EntityManagerFactory emf;
	EntityManager em;
	EntityTransaction et;

	public AddressDAOImpl() {
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		this.em = emf.createEntityManager();
		this.et = em.getTransaction();

	}

	public void createAddress(Address addnew) {
		et.begin();
		em.persist(addnew);
		et.commit();

	}

	public Address selectAddress(int addId) {
		// TODO Auto-generated method stub
		Address selAdd = em.find(Address.class, addId); // 2 is primary key
		try {
			System.out.println(" Address Id		:" + selAdd.getAddressId());
			System.out.println(" Area			:" + selAdd.getArea());
			System.out.println(" Street			:" + selAdd.getStreet());
			System.out.println(" City			:" + selAdd.getCity());
			System.out.println(" Country		:" + selAdd.getCountry());
			System.out.println(" PIN			:" + selAdd.getPin());

		} catch (Exception e) {
			System.out.println("No record Found");
		}
		return selAdd;

		
	}

	public void updateAddress(Address addUpdate) {
		// TODO Auto-generated method stub
		et.begin();
		em.merge(addUpdate);
		et.commit();
	}

	public void deleteAddress(String addId) {
		// TODO Auto-generated method stub
		Address selAdd = em.find(Address.class, addId); // 2 is primary key
		try {
			System.out.println(" Address Id		:" + selAdd.getAddressId());
			System.out.println(" Area			:" + selAdd.getArea());
			System.out.println(" Street			:" + selAdd.getStreet());
			System.out.println(" City			:" + selAdd.getCity());
			System.out.println(" Country		:" + selAdd.getCountry());
			System.out.println(" PIN			:" + selAdd.getPin());
			et.begin();
			em.remove(selAdd);
			et.commit();

		} catch (Exception e) {
			System.out.println("No record Found");
		}

	}

	public void selectAllAddresses() {
		// TODO Auto-generated method stub
		Query query = em.createQuery("from Address");
		List<Address> addList = query.getResultList();
		if (addList.size() > 0) {
			for (Address currAdd : addList) {
				System.out.println(" Address Id		:" + currAdd.getAddressId());
				System.out.println(" Area			:" + currAdd.getArea());
				System.out.println(" Street			:" + currAdd.getStreet());
				System.out.println(" City			:" + currAdd.getCity());
				System.out.println(" Country		:" + currAdd.getCountry());
				System.out.println(" PIN			:" + currAdd.getPin());
				System.out.println("====================================");

			}
		}

	}

		

}
