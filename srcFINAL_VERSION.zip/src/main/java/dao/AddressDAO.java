package dao;

import entity.Address;

public interface AddressDAO {
	public void createAddress(Address addnew);
	public Address selectAddress(int addId);
	public void updateAddress(Address addUpdate);
	public void deleteAddress(String addId);
	public void selectAllAddresses();

}
