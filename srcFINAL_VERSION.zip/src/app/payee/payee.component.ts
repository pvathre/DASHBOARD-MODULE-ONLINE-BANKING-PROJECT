import { Component, OnInit } from '@angular/core';
import { PayeeService } from '../payee.service';
import { Payee } from './Payee';

@Component({
  selector: 'app-payee',
  templateUrl: './payee.component.html',
  styleUrls: ['./payee.component.css']
})
export class PayeeComponent implements OnInit {
  applarray:Payee[]=[];
  appl:Payee=new Payee();
  constructor(private aps:PayeeService) { }

  ngOnInit(): void {
    this.showall();
  }

 deletedOrNot: boolean=false;
 msg:string ='';
  delete( payeeid:number){
   
    console.log('inside delete');
    this.aps.remove(payeeid).subscribe(
      (answer)=> {
        
         this.deletedOrNot=answer;

        if(this.deletedOrNot==true) {
         
          console.log('deleted');
        }
      }, (err) => {
       
          console.log(err);
      }
    );
    alert("Payee has been deleted");
    window.location.reload();
   /*if( this.aps.remove(payeeid)){
     alert("Payee Deleted");
     window.location.reload();
   };*/
  }
  showall()
  {
    
    console.log("in show all")
    this.aps.fetchall().subscribe(
  (data:Payee[])=>
  {this.applarray=data;}
  
    );
  }

}
