import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { isEmpty } from 'rxjs';
import { Applicant } from '../applicant-new/Applicant';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-applogin',
  templateUrl: './applogin.component.html',
  styleUrls: ['./applogin.component.css']
})
export class ApploginComponent implements OnInit {
username:string="";
password:string="";

  constructor(private router:Router,private authObj:AuthenticationService ) { }

  ngOnInit(): void {
  }

  appl :Applicant= new Applicant();
  loginAs(){

    this.authObj.authenticate(this.username,this.password).subscribe(
      (data:Applicant)=>
      {
        this.appl=data;
        
        if( !this.appl){
          alert("Invalid Credentials");
        }else{
        sessionStorage.setItem('userType','user');
        sessionStorage.setItem('userName',this.appl.applicantName);
        sessionStorage.setItem('userPhoto',this.appl.photo);
        sessionStorage.setItem('appObj',JSON.stringify(this.appl));
        window.location.reload();
      }
      
      }
      ); ;
  }

}
