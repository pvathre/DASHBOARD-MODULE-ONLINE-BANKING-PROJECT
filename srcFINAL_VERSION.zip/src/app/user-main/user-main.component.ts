import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as Highcharts from 'highcharts';
import { AuthenticationService } from '../authentication.service';
import { SpendAnalysisComponent } from '../spend-analysis/spend-analysis.component';


@Component({
  selector: 'app-user-main',
  templateUrl: './user-main.component.html',
  styleUrls: ['./user-main.component.css']
})
export class UserMainComponent implements OnInit {

  constructor(public router:Router,private authObj:AuthenticationService) { }

  ngOnInit(): void {
     this.authObj.verifyUser();

   }

   showchart(){
     // this.spObj.getSpendDet();
   }
  }

