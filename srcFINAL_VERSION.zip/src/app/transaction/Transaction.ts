export class Transaction{
    txnId: number =0;
    txnDate: Date =  new Date();
    txnAmt:number =0;
    txnType: string ='';
    txnToAcc:string='';
    txnDetails:string='';
    currBalSrc:number=0;
}