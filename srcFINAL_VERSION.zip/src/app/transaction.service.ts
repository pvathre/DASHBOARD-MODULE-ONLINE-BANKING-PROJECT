import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Transaction } from './transaction/Transaction';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  constructor(private myhttp:HttpClient) { }


  fetchTentxn(accNo:number):Observable<Transaction[]>
  {
    
    return this.myhttp.get<Transaction[]>("http://localhost:8080/txns/getMini/"+accNo);
  
  }
  fetchAlltxn(accNo:number):Observable<Transaction[]>
  {
    return this.myhttp.get<Transaction[]>("http://localhost:8080/txns/getAll/"+accNo);
  
  }
}
