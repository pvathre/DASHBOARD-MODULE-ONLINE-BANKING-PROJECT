import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { UserMainComponent } from './user-main/user-main.component';
import { UserTopMenuComponent } from './user-top-menu/user-top-menu.component';


import { UserLeftMenuComponent } from './user-left-menu/user-left-menu.component';
import { FAQComponent } from './faq/faq.component';
import { InterestcalComponent } from './interestcal/interestcal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AboutusComponent } from './aboutus/aboutus.component';
import { ApploginComponent } from './applogin/applogin.component';
import { ApplicantNewComponent } from './applicant-new/applicant-new.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AccountComponent } from './account/account.component';
import { HomeComponent } from './home/home.component';
import { LatestNewsComponent } from './latest-news/latest-news.component';
import { LogoutComponent } from './home/logout/logout.component';
import { PayeeComponent } from './payee/payee.component';
import { IonicModule } from '@ionic/angular';
import { SpendAnalysisComponent } from './spend-analysis/spend-analysis.component';
import { TransactionComponent } from './transaction/transaction.component';

//TABS
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatTabsModule} from '@angular/material/tabs';
import { HighchartsChartModule } from 'highcharts-angular';
import { SideTabComponent } from './side-tab/side-tab.component';
import { StatementComponent } from './statement/statement.component';





@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    
    UserMainComponent,
    UserTopMenuComponent,
    
    
    UserLeftMenuComponent,
    FAQComponent,
    InterestcalComponent,
    
    AboutusComponent,
    ApploginComponent,
    ApplicantNewComponent,
    AccountComponent,
    HomeComponent,
    LatestNewsComponent,
    LogoutComponent,
    PayeeComponent,
    SpendAnalysisComponent,
    TransactionComponent,
    SideTabComponent,
    StatementComponent
    
        
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    
    HttpClientModule,
    IonicModule.forRoot(),
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatTabsModule,
    HighchartsChartModule


  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
