export class Account{
       
    accountNumber:number=0;
    accountHolderName:string= "Akansha";
    accountBalnce:number= 5000.0;

}