import { Statement } from '@angular/compiler';
import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AccountComponent } from './account/account.component';
import { ApplicantNewComponent } from './applicant-new/applicant-new.component';

import { ApploginComponent } from './applogin/applogin.component';

import { FAQComponent } from './faq/faq.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './home/logout/logout.component';
import { InterestcalComponent } from './interestcal/interestcal.component';
import { PayeeComponent } from './payee/payee.component';
import { SpendAnalysisComponent } from './spend-analysis/spend-analysis.component';
import { SpendAnalysis } from './spend-analysis/SpendAnalysis';
import { StatementComponent } from './statement/statement.component';
import { TransactionComponent } from './transaction/transaction.component';
import { UserMainComponent } from './user-main/user-main.component';

const routes: Routes = [
  {path:'',redirectTo:'/home',pathMatch:'full'},
{ path:'faq', component:FAQComponent},
{path:'interest', component:InterestcalComponent},
{path:'aboutus', component:AboutusComponent},
{path:'login',component:ApploginComponent},
{path:'app',component:ApplicantNewComponent},
{path:'acc',component:AccountComponent},
{ path:'user', component:UserMainComponent},
{ path:'payee', component:PayeeComponent},
{ path:'statement', component:StatementComponent},
{
  path:'home',
    children: [
      {path:'',component:HomeComponent},
      {path:'logout',component:LogoutComponent}
    ]
},
{path: 'txn/:accNo', component: TransactionComponent},
{path: 'spend', component: SpendAnalysisComponent}

//{ path:'logout', component:Log}, 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
