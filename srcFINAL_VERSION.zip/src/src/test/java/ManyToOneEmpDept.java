import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import entity.Department;
import entity.Employee;
import entity.Passport;

public class ManyToOneEmpDept {
	EntityManagerFactory emf;
	EntityManager em ;
	
	public ManyToOneEmpDept() {
		
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		this.em = emf.createEntityManager();
		
	}
	
	@Test
	public void createDepartment() {
		Department newdept = new Department();
		newdept.setDeptName("CBOPS");
		newdept.setDeptLocation("Nerul");
		EntityTransaction et = em.getTransaction();
		et.begin();
			em.persist(newdept);
		et.commit();	
	}
	
	@Test
	public void createDeptEmpPass() {
		Department newdept = new Department();
		newdept.setDeptName("CBOPS");
		newdept.setDeptLocation("Nerul");
		
		Employee emp1 = new Employee();
		emp1.setName("Nimya");
		emp1.setAge(35);
		emp1.setJob("TO Sys");
		emp1.setJoiningDate(LocalDate.of(2020, 10, 20));
		emp1.setSalary(50000);
		emp1.setDept_no(newdept);
		
		Employee emp2 = new Employee();
		emp2.setName("Tiyana");
		emp2.setAge(32);
		emp2.setJob("SO Sys");
		emp2.setJoiningDate(LocalDate.of(2000, 10, 20));
		emp2.setSalary(70000);
		emp2.setDept_no(newdept);
		
		Employee emp3 = new Employee();
		emp3.setName("Rose");
		emp3.setAge(25);
		emp3.setJob("Sales");
		emp3.setJoiningDate(LocalDate.of(2220, 10, 20));
		emp3.setSalary(35000);
		emp3.setDept_no(newdept);
		
		Passport newpass1 = new Passport();
		newpass1.setPassportNumber("DBC45JN");
		newpass1.setIssueDate(LocalDate.of(2020, 8, 10));
		newpass1.setExpiryDate(LocalDate.of(2030, 8, 10));
		newpass1.setIssuedBy("Govt of India");
		
		Passport newpass2 = new Passport();
		newpass2.setPassportNumber("RTC45JN");
		newpass2.setIssueDate(LocalDate.of(2020, 8, 10));
		newpass2.setExpiryDate(LocalDate.of(2030, 8, 10));
		newpass2.setIssuedBy("Govt of USA");
		
		Passport newpass3 = new Passport();
		newpass3.setPassportNumber("UBP50JN");
		newpass3.setIssueDate(LocalDate.of(2020, 8, 10));
		newpass3.setExpiryDate(LocalDate.of(2030, 8, 10));
		newpass3.setIssuedBy("Govt of Russia");
		
		emp1.setPassport(newpass1);
		emp2.setPassport(newpass2);
		emp3.setPassport(newpass3);
		
		newpass1.setEmp_id(emp1);
		newpass2.setEmp_id(emp2);
		newpass3.setEmp_id(emp3);
		
		Set<Employee> staffList = new HashSet<Employee>();
		staffList.add(emp1);
		staffList.add(emp2);
		staffList.add(emp3);
		
		
		newdept.setStaffList(staffList);
		EntityTransaction et = em.getTransaction();
		et.begin();
			em.persist(newdept);
		et.commit();
		
		
	}
}
