import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import entity.Employee;

public class CrudTesting {
	
	EntityManagerFactory emf;
	EntityManager em ;		
	EntityTransaction et;
	
	 public CrudTesting() {
		this.emf =Persistence.createEntityManagerFactory("MyJPA");
		this.em = emf.createEntityManager();		
		this.et = em.getTransaction();
			
	}
	
	
	@Test
	public void createEmployeetest() {
		System.out.println("Trying to read persistence.xml...");	
		
		
		Employee emp = new Employee();
		emp.setName("Jacky");
		emp.setJob("Manager");
		emp.setJoiningDate(LocalDate.of(2020, 10, 20));
		emp.setSalary(70000);
		
		
		et.begin();
			em.persist(emp);
		et.commit();
			
	}
	
	@Test
	public void selectEmployee() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("MyJPA");
	Assertions.assertTrue(emf!=null);	
		EntityManager em = emf.createEntityManager();		
	Assertions.assertTrue(em!=null);				
		Employee empList = em.find(Employee.class, 2); //2 is primary key 
		
	Assertions.assertTrue(empList!=null);	
		System.out.println(" Id       :"+empList.getEmployeeNumber());
		System.out.println(" Name     :"+empList.getName());
		System.out.println(" Age      :"+empList.getAge());
		System.out.println(" Salary   :"+empList.getSalary());
		System.out.println(" Job      :"+empList.getJob());
		
	}
	
	
	
	@Test
	public void updateEmployee() {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("MyJPA");
	Assertions.assertTrue(emf!=null);	
		EntityManager em = emf.createEntityManager();		
	Assertions.assertTrue(em!=null);	
		EntityTransaction et = em.getTransaction();
	Assertions.assertTrue(et!=null);	
		Employee empList = em.find(Employee.class, 1); //2 is primary key //ATTACHED OBJECT
		
	Assertions.assertTrue(empList!=null);	
		et.begin();
		System.out.println(" Id       :"+empList.getEmployeeNumber());
		System.out.println(" Name     :"+empList.getName());
		System.out.println(" Age      :"+empList.getAge());
		System.out.println(" Salary   :"+empList.getSalary());
		System.out.println(" Job      :"+empList.getJob());
		
		empList.setAge((int) empList.getAge()+30);
		empList.setSalary(empList.getSalary()+5000);
		
		em.merge(empList);
		et.commit();
		
	}
	
	
	@Test
	public void updateEmployee2() {		
	
		Employee empList = new Employee(); //TRANSIENT OBJECT
		empList.setEmployeeNumber(2);
		empList.setAge(34);		
		empList.setJob("Analyst");
		empList.setJoiningDate(LocalDate.of(2020, 10, 06));
		empList.setSalary(50000);
		
		et.begin();
			em.merge(empList);
		et.commit();
		
	}
	
	
}
