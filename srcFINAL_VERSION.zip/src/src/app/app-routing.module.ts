import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AccountComponent } from './account/account.component';
import { ApplicantNewComponent } from './applicant-new/applicant-new.component';

import { ApploginComponent } from './applogin/applogin.component';

import { FAQComponent } from './faq/faq.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './home/logout/logout.component';
import { InterestcalComponent } from './interestcal/interestcal.component';
import { PayeeComponent } from './payee/payee.component';
import { UserMainComponent } from './user-main/user-main.component';

const routes: Routes = [
  {path:'',redirectTo:'/home',pathMatch:'full'},
{ path:'faq', component:FAQComponent},
{path:'interest', component:InterestcalComponent},
{path:'aboutus', component:AboutusComponent},
{path:'login',component:ApploginComponent},
{path:'app',component:ApplicantNewComponent},
{path:'acc',component:AccountComponent},
{ path:'user', component:UserMainComponent},
{ path:'payee', component:PayeeComponent},
{
  path:'home',
    children: [
      {path:'',component:HomeComponent},
      {path:'logout',component:LogoutComponent}
    ]
},

//{ path:'logout', component:Log}, 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
