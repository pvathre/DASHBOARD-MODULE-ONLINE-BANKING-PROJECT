import { Component, OnInit } from '@angular/core';
import { PayeeService } from '../payee.service';
import { Payee } from './Payee';

@Component({
  selector: 'app-payee',
  templateUrl: './payee.component.html',
  styleUrls: ['./payee.component.css']
})
export class PayeeComponent implements OnInit {
  applarray:Payee[]=[];
  appl:Payee=new Payee();
  constructor(private aps:PayeeService) { }

  ngOnInit(): void {
    
  }

  showall()
  {console.log("in show all")
    this.aps.fetchall().subscribe(
  (data:Payee[])=>
  {this.applarray=data;}
  
    );
  }

}
