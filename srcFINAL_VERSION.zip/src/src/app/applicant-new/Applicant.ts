export class Applicant{
    applicantid:number=0;
    applicantName:string="";
    mobileNumb:string="";
    applicantFatherName:string="";
    applicantMotherName:string="";
    married:string="";
    aadhar:string="";
    panCard:string="";
    photo:string="";
    applicant_status:string="";
    account_type:string="";    
}
