import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-left-menu',
  templateUrl: './user-left-menu.component.html',
  styleUrls: ['./user-left-menu.component.css']
})
export class UserLeftMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
