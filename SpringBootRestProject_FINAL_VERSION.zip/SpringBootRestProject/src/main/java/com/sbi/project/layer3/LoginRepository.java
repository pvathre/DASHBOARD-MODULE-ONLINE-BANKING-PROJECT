package com.sbi.project.layer3;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.sbi.project.layer2.Applicant;

@CrossOrigin(origins = "http://localhost:4200")
@Repository
public interface LoginRepository  {
	Applicant findLogin(String userName,String password);
	
}
