package com.sbi.project.layer3;

import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.Login;
@CrossOrigin(origins = "http://localhost:4200")
@Repository
public class LoginRepositoryImpl extends BaseRepositoryImpl implements LoginRepository {
	@Autowired
	ApplicantRepository apprepo;
			@Override
	public Applicant findLogin(String userName, String password) {
		// TODO Auto-generated method stub
				Login newlogin = new Login();	
				try {
			
		TypedQuery<Login> query = entityManager.createQuery("from Login l where "
						+ "l.userName=:x AND l.password=:y", Login.class);
		query.setParameter("x", userName);
		query.setParameter("y", password);
		newlogin =query.getSingleResult();
		}catch(NoResultException e) {
					return null;
				}
		Applicant app = apprepo.findApp(newlogin.getUserId());
		return app;
				
	}
}
