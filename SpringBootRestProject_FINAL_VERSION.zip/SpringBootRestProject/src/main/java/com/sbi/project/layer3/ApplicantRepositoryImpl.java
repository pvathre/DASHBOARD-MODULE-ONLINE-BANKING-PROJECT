package com.sbi.project.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import com.sbi.project.layer2.Applicant;

@Repository
public class ApplicantRepositoryImpl extends BaseRepositoryImpl implements ApplicantRepository {

	@Transactional 
	public void createApp(Applicant app) {
		super.persist(app);
		}
	
	@Transactional
	public void modifyApp(Applicant app) {
		super.merge(app);
		
	}
	
	@Transactional
	public void removeApp(int apno) {
		Applicant a=super.find(Applicant.class,apno);
		super.remove(a);
		
	}
	public Applicant findApp(int apno) {
		
		
		return super.find(Applicant.class,apno);
		}
	
	public List<Applicant> findAllApp(){
		return super.findAll("Applicant");}
	
	
	
	
	
}
