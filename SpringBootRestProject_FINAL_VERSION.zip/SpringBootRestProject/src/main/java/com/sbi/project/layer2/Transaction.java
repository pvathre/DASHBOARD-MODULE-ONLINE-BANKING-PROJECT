package com.sbi.project.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Component
@Entity
@Table(name="txn_tbl")
public class Transaction {
	@Id
	@GeneratedValue
	@Column(name="txn_id")
	private int txnId;
	
	@Column(name="txn_date")
	private String txnDate;
	
	@Column(name="txn_amt")
	private float txnAmt;	
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="txn_from_acc")
	private Account txnFromAcc;
	
	@Column(name="txn_type")
	private String txnType;
	
	
	@Column(name="txn_to_acc")
	private String txnToAcc;
	
	@Column(name="txn_det")
	private String txnDetails;
	
	@Column(name="txn_bal_src")
	private float currBalSrc;
	
	public int getTxnId() {
		return txnId;
	}

	public void setTxnId(int txnId) {
		this.txnId = txnId;
	}

	public String getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	public float getTxnAmt() {
		return txnAmt;
	}

	public void setTxnAmt(float txnAmt) {
		this.txnAmt = txnAmt;
	}

	

	public Account getTxnFromAcc() {
		return txnFromAcc;
	}

	public void setTxnFromAcc(Account txnFromAcc) {
		this.txnFromAcc = txnFromAcc;
	}

	public float getCurrBalSrc() {
		return currBalSrc;
	}

	public void setCurrBalSrc(float currBalSrc) {
		this.currBalSrc = currBalSrc;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getTxnToAcc() {
		return txnToAcc;
	}

	public void setTxnToAcc(String txnToAcc) {
		this.txnToAcc = txnToAcc;
	}

	public String getTxnDetails() {
		return txnDetails;
	}

	public void setTxnDetails(String txnDetails) {
		this.txnDetails = txnDetails;
	}

	@Override
	public String toString() {
		return "Transaction [txnId=" + txnId + ", txnDate=" + txnDate + ", txnAmt=" + txnAmt + ", txnFromAcc="
				+ txnFromAcc + ", txnType=" + txnType + ", txnToAcc=" + txnToAcc + ", txnDetails=" + txnDetails + "]";
	}
	
	
	
	

}
